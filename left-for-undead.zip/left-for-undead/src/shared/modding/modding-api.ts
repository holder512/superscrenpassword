import { Modding } from "@flamework/core";

export namespace LeftForUndeadApi {
	export function replaceAsset(tag: string, model: Model) {}
}
