export enum PickupType {
	AMMO = 0,
	HEALTH = 1,
	WEAPON = 2,
}

export interface PickupDataKey {
	id: string;
	gives: Array<{
		type: PickupType;
		params: {
			quantity?: number; // Percentage of ammo to restore. If type == HEALTH, restores n health points.
			weaponId?: string; // Only applies if type == WEAPON.
		};
	}>;
}

export const PickupData: Array<PickupDataKey> = [
	{
		id: "pickup.ammo.small",
		gives: [
			{
				type: PickupType.AMMO,
				params: {
					quantity: 10,
				},
			},
		],
	},
	{
		id: "pickup.ammo.medium",
		gives: [
			{
				type: PickupType.AMMO,
				params: {
					quantity: 30,
				},
			},
		],
	},
	{
		id: "pickup.ammo.large",
		gives: [
			{
				type: PickupType.AMMO,
				params: {
					quantity: 80,
				},
			},
		],
	},
	{
		id: "pickup.health.small",
		gives: [
			{
				type: PickupType.HEALTH,
				params: {
					quantity: 30,
				},
			},
		],
	},
	{
		id: "pickup.health.medium",
		gives: [
			{
				type: PickupType.HEALTH,
				params: {
					quantity: 60,
				},
			},
		],
	},
	{
		id: "pickup.health.small",
		gives: [
			{
				type: PickupType.HEALTH,
				params: {
					quantity: 90,
				},
			},
		],
	},
];
