export type EnemyDataKey = {
	id: string;
	health: number;
	walkSpeed: number;
};

export const EnemyData: [EnemyDataKey] = [
	{
		id: "COMMON_INFECTED",
		health: 100,
		walkSpeed: 10,
	},
];
