export type ViewmodelAnimationKey = {
	Equip: string;
	Fire: string;
	Idle: string;
	Reload: string;
	Shove: string;
};

export const ViewmodelAnimations = {
	pistol: {
		Equip: "rbxassetid://17712117107",
		Fire: "rbxassetid://17712571122",
		Idle: "rbxassetid://17712205121",
		Reload: "rbxassetid://17712296143",
		Shove: "rbxassetid://16864847276",
	},
	uzi: {
		Fire: "rbxassetid://17711112194",
		Idle: "rbxassetid://17711116765",
		Reload: "rbxassetid://17711124505",
		Equip: "rbxassetid://17711132175",
		Shove: "rbxassetid://17711140339",
	},
} as { [key: string]: ViewmodelAnimationKey };
