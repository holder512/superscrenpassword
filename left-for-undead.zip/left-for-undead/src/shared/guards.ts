import type { CommandContext, CommandGuard } from "@rbxts/commander";

const groupId = 11838211;
export const isAdmin: CommandGuard = (ctx: CommandContext) => {
	return ctx.executor?.GetRankInGroup(groupId) >= 253;
};

export const isTester: CommandGuard = (ctx: CommandContext) => {
	return ctx.executor?.GetRankInGroup(groupId) >= 2;
};

export const isTrusted: CommandGuard = (ctx: CommandContext) => {
	return ctx.executor?.GetRankInGroup(groupId) >= 5;
};
