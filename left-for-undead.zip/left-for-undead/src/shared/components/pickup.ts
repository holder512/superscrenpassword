import { BaseComponent, Component } from "@flamework/components";
import { OnRender, type OnStart, OnTick } from "@flamework/core";
import { ReplicatedStorage, TweenService } from "@rbxts/services";
import { PickupData, PickupDataKey } from "shared/data/pickups";

interface Attributes {
	id: string;
	position: Vector3;
}

@Component({
	defaults: {
		id: "pickup.ammo.large",
		position: new Vector3(0, 0, 0),
	},
})
export class Pickup extends BaseComponent<Attributes> implements OnStart {
	public model: BasePart | undefined;
	private tween: Tween | undefined;

	onStart() {
		print(`attached to ${this.instance}`);
		const pickupModelsFolder =
			ReplicatedStorage.WaitForChild("Client").WaitForChild("Pickups");

		(this.instance as BasePart).PivotTo(new CFrame(this.attributes.position));

		const initialCFrame = (this.instance as BasePart).CFrame;

		this.tween = TweenService.Create(
			this.instance as BasePart,
			new TweenInfo(
				4,
				Enum.EasingStyle.Linear,
				Enum.EasingDirection.InOut,
				-1,
				false,
			),
			{
				Orientation: new Vector3(0, 360, 0),
			},
		);
		this.tween.Play();
	}
}
