import { createProducer } from "@rbxts/reflex";
import type { EnemyState } from "./types/enemy-state";

export interface SharedState {
	enemies: Set<EnemyState>;
	wave: number;
}

const initialState: SharedState = {
	enemies: new Set(),
	wave: 0,
};

export const state = createProducer(initialState, {
	addEnemy: (state, enemy: EnemyState) => ({
		...state,
		enemies: new Set([...state.enemies, enemy]),
	}),

	removeEnemy: (state, enemy: EnemyState) => ({
		...state,
		enemies: new Set([...state.enemies].filter((e) => e !== enemy)),
	}),

	setWave: (state, wave: number) => ({
		...state,
		wave: wave,
	}),
});
