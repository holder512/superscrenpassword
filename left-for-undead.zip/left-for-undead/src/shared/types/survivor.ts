import { type Character, DefaultCharacterStats } from "./default-character";

export enum Survivor {
	Bill = 0,
	Francis = 1,
	Louis = 2,
	Zoey = 3,
	Coach = 4,
	Nick = 5,
	Ellis = 6,
	Rochelle = 7,
}

export type SurvivorStatsKey = Character & { name: string };

// eslint-disable-next-line prefer-const
export const SurvivorStats = [
	{ name: "Bill", ...DefaultCharacterStats },
	{ name: "Francis", ...DefaultCharacterStats },
	{ name: "Louis", ...DefaultCharacterStats },
	{ name: "Zoey", ...DefaultCharacterStats },
	{ name: "Coach", ...DefaultCharacterStats },
	{ name: "Nick", ...DefaultCharacterStats },
	{ name: "Ellis", ...DefaultCharacterStats },
	{ name: "Rochelle", ...DefaultCharacterStats },
];
