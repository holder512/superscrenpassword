import { TransformResult, TypeBuilder } from "@rbxts/commander";
import { t } from "@rbxts/t";

export const commanderVector3Type = TypeBuilder.create<Vector3>("vector")
	.validate(t.Vector3)
	.transform((text, executor) => {
		const components = text.split(",");
		const x = tonumber(components[0])!;
		const y = tonumber(components[1])!;
		const z = tonumber(components[2])!;

		return TransformResult.ok(new Vector3(x, y, z));
	})
	.build();
