import { TransformResult, TypeBuilder } from "@rbxts/commander";
import { t } from "@rbxts/t";
import { PickupData } from "shared/data/pickups";
import { sounds } from "shared/data/sounds";

export const commanderPickupIdType = TypeBuilder.create<string>("pickupid")
	.validate(t.string)
	.transform((text, executor: Player | undefined) => {
		// Filter the data that is equal to the text
		const containsText = PickupData.filter((value) => {
			return value.id === text;
		});

		if (containsText.size() >= 0) {
			return TransformResult.ok(text);
		}
		return TransformResult.err(text);
	})
	.suggestions((text, executor) => {
		// Filter all of the data that includes the target text.
		const valuesThatIncludeText = PickupData.filter((value) => {
			return value.id.match(text)[0] !== undefined;
		});

		// Filter the suggestions down to the ID of each vaue.
		const suggestions = valuesThatIncludeText.map((value) => {
			return value.id;
		});

		return suggestions;
	})
	.build();
