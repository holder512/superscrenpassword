import { TransformResult, TypeBuilder } from "@rbxts/commander";
import { t } from "@rbxts/t";
import { sounds } from "shared/data/sounds";

export const commanderSoundIdType = TypeBuilder.create<string>("soundid")
	.validate(t.string)
	.transform((text, executor: Player | undefined) => {
		// Filter the data that is equal to the text
		const containsText = sounds.filter((value) => {
			return value.name === text;
		});

		if (containsText.size() >= 0) {
			return TransformResult.ok(text);
		}
		return TransformResult.err(text);
	})
	.suggestions((text, executor) => {
		// Filter all of the data that includes the target text.
		const valuesThatIncludeText = sounds.filter((value) => {
			return value.name.match(text)[0] !== undefined;
		});

		// Filter the suggestions down to the ID of each vaue.
		const suggestions = valuesThatIncludeText.map((value) => {
			return value.name;
		});

		return suggestions;
	})
	.build();
