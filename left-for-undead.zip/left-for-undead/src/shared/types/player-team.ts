export type PlayerTeam = "Survivor";
