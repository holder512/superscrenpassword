export interface Character {
	survivor: boolean;
	health: number;
	jumpPower: number;
	speed: number;
	taken: boolean;
}

// eslint-disable-next-line prefer-const
export const DefaultCharacterStats: Character = {
	survivor: true,
	health: 100,
	jumpPower: 10,
	speed: 16,
	taken: false,
};
