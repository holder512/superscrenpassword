/**
 * @name EnemyState
 * @description Used in networking for syncing enemies to clients.
 */
export type EnemyState = {
	cFrame: CFrame;
	playingAnimations: Array<{
		animationId: string;
		animationSpeed: number;
		animationTime: number;
	}>;
	id: string;
};
