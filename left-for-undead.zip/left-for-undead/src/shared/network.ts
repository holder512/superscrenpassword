import { Networking } from "@flamework/networking";
import { PickupDataKey } from "./data/pickups";

interface ClientToServerEvents {
	weapon: {
		fire(bulletType: string, origin: Vector3, hit: Vector3): void;
	};
	environment: {
		playSound(id: string, origin?: Vector3, loudness?: number): void;
	};
	removePickup: (object: BasePart) => void;
}

interface ServerToClientEvents {
	command: {
		freecamToggle: (state: boolean) => void;
	};
	character: {
		initialize: () => void;
	};
	weapon: {
		fireVisual: (
			player: Player,
			bulletType: string,
			origin: Vector3,
			hit: Vector3,
		) => void;
	};
	environment: {
		broadcastSound(id: string, origin?: Vector3, loudness?: number): void;
	};
}

type ClientToServerFunctions = {};

type ServerToClientFunctions = {};

export const GlobalEvents = Networking.createEvent<
	ClientToServerEvents,
	ServerToClientEvents
>();
export const GlobalFunctions = Networking.createFunction<
	ClientToServerFunctions,
	ServerToClientFunctions
>();
