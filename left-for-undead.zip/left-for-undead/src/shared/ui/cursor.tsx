import {
	Command,
	CommandContext,
	Commander,
	CommanderType,
} from "@rbxts/commander";
import React, { Component, ReactComponent, type ReactNode } from "@rbxts/react";
import { Players, RunService } from "@rbxts/services";
import { GlobalEvents } from "shared/network";

interface CursorProps {
	gap: number;
	crossSize: number;
	crossWidth: number;
	dotSize: number;
	color: Color3;
}

interface CursorState {
	gap: number;
	color: Color3;
}

@ReactComponent
export class Cursor extends Component<CursorProps, CursorState> {
	state: CursorState = {
		gap: this.props.gap,
		color: this.props.color,
	};

	private button1DownConnection?: RBXScriptConnection;
	private heartbeatConnection?: RBXScriptConnection;

	constructor(props: CursorProps) {
		super(props);
		this.state = {
			gap: props.gap,
			color: props.color,
		};
	}

	componentDidMount() {
		GlobalEvents.createClient({}).weapon.fireVisual.connect((player) => {
			if (player === Players.LocalPlayer) {
				this.setState({ gap: 15 });
				if (this.heartbeatConnection) {
					this.heartbeatConnection.Disconnect();
				}
				this.heartbeatConnection = RunService.Heartbeat.Connect(() =>
					this.updateGap(),
				);
			}
		});
	}

	changeColor(color: Color3) {
		this.setState({
			color: color,
		});
	}

	componentWillUnmount() {
		if (this.button1DownConnection) {
			this.button1DownConnection.Disconnect();
		}
		if (this.heartbeatConnection) {
			this.heartbeatConnection.Disconnect();
		}
	}

	updateGap() {
		const { gap } = this.state;
		const timeToNormal = 0.5;
		if (gap > 4) {
			this.setState({ gap: gap - 0.25 });
			task.wait(timeToNormal / gap);
		} else if (this.heartbeatConnection) {
			this.heartbeatConnection.Disconnect();
		}
	}

	render() {
		const { crossSize, crossWidth, dotSize } = this.props;
		const { gap } = this.state;

		const color: Color3 = this.state.color;

		return (
			<frame
				BackgroundColor3={color}
				Position={new UDim2(0.5, -dotSize / 2, 0.5, -dotSize / 2)}
				Size={new UDim2(0, dotSize, 0, dotSize)}
				BorderSizePixel={0}
			>
				<frame
					BackgroundColor3={color}
					Position={new UDim2(0.5, -(crossSize + gap), 0.5, -crossWidth / 2)}
					Size={new UDim2(0, crossSize, 0, crossWidth)}
					BorderSizePixel={0}
				/>
				<frame
					BackgroundColor3={color}
					Position={new UDim2(0.5, gap, 0.5, -crossWidth / 2)}
					Size={new UDim2(0, crossSize, 0, crossWidth)}
					BorderSizePixel={0}
				/>
				<frame
					BackgroundColor3={color}
					Position={new UDim2(0.5, -crossWidth / 2, 0.5, -(gap + crossSize))}
					Size={new UDim2(0, crossWidth, 0, crossSize)}
					BorderSizePixel={0}
				/>
				<frame
					BackgroundColor3={color}
					Position={new UDim2(0.5, -crossWidth / 2, 0.5, gap)}
					Size={new UDim2(0, crossWidth, 0, crossSize)}
					BorderSizePixel={0}
				/>
			</frame>
		) as unknown as ReactNode;
	}
}
