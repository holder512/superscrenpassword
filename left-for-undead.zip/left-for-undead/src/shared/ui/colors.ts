export const Colors = {
	primary: Color3.fromHex("#97E343"),
	secondary: Color3.fromRGB(168, 168, 168),
};
