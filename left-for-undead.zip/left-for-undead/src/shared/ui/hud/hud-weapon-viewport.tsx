import Make from "@rbxts/make";
import { useMountEffect } from "@rbxts/pretty-react-hooks";
import React, { useRef } from "@rbxts/react";
import { ReplicatedStorage } from "@rbxts/services";
import { Colors } from "../colors";

interface HudProps {
	weapon: string;
	active: boolean;
	Native?: Partial<InstanceProperties<ViewportFrame>>;
}

export function HudWeaponViewport(props: HudProps) {
	const viewportReference = useRef<ViewportFrame>();

	useMountEffect(() => {
		const viewport = viewportReference.current;

		const obj = ReplicatedStorage.WaitForChild("Client")
			.WaitForChild("Viewports")
			.WaitForChild(props.weapon)
			.Clone();

		obj.Parent = viewport;

		const viewportCamera = Make("Camera", {
			CFrame: new CFrame(obj.GetAttribute("cPos") as Vector3),
			Parent: viewport,
		});

		viewport!.CurrentCamera = viewportCamera;
	});

	return (
		<viewportframe
			{...props.Native}
			ref={viewportReference}
			ImageColor3={props.active ? Colors.primary : Colors.secondary}
		/>
	);
}
