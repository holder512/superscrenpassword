import { DefaultPalette } from "@rbxts/commander";
import { KeyCodes } from "@rbxts/pretty-react-hooks";
import type React from "@rbxts/react";
import { Component, ReactComponent, ReactNode } from "@rbxts/react";
import { Colors } from "../colors";
import { Frame } from "../commander-styled/frame";
import { HudWeaponViewport } from "./hud-weapon-viewport";

interface HudProps {
	weapons: Array<HudWeaponState>;
	currentlySelectedWeapon: string;
}

interface HudWeaponState {
	clip: number;
	reserveAmmo: number;
	id: string;
}

interface HudState {
	weapons: Array<HudWeaponState>;
	currentlySelectedWeapon: string;
}

export function transformForHUD(
	weapons: Array<{
		ammo: number;
		reserveAmmo: number;
		id: string;
	}>,
) {
	const newArray: Array<HudWeaponState> = [];
	weapons.forEach((weapon) => {
		newArray.push({
			clip: weapon.ammo,
			reserveAmmo: weapon.reserveAmmo,
			id: weapon.id,
		});
	});
	return newArray;
}

@ReactComponent
export class Hud extends Component<HudProps, HudState> {
	// ===
	equalTo(weapon: HudWeaponState) {
		return this.props.currentlySelectedWeapon === weapon.id;
	}

	render(): React.ReactNode {
		return (
			<Frame
				backgroundColor={DefaultPalette.frappe.background}
				backgroundTransparency={0.2}
				cornerRadius={new UDim(0, 4)}
				size={new UDim2(0, 140, 0, 360)}
				position={new UDim2(1, -140, 0.5, 0)}
				anchorPoint={new Vector2(0, 0.5)}
			>
				<frame
					BackgroundTransparency={1}
					Size={new UDim2(1, -20, 1, -50)}
					Position={new UDim2(0, 10, 0, 40)}
				>
					<uilistlayout
						Padding={new UDim(0, 20)}
						FillDirection={"Vertical"}
						HorizontalAlignment={"Center"}
						VerticalAlignment={"Top"}
						SortOrder={"Name"}
					/>
					{this.props.weapons.map((weapon, index) => (
						<Frame
							backgroundColor={DefaultPalette.frappe.background}
							backgroundTransparency={0.2}
							cornerRadius={new UDim(0, 4)}
							size={
								this.equalTo(weapon)
									? new UDim2(1, 0, 0, 60)
									: new UDim2(1, -35, 0, 52)
							}
							key={this.equalTo(weapon) ? 0 : index}
						>
							<uistroke
								Color={this.equalTo(weapon) ? Colors.primary : Colors.secondary}
								Thickness={4}
								Transparency={0.2}
							/>
							<HudWeaponViewport
								active={this.equalTo(weapon)}
								weapon={weapon.id}
								Native={{
									Ambient: new Color3(1, 1, 1),
									LightColor: new Color3(1, 1, 1),
									Size: this.equalTo(weapon)
										? new UDim2(1, 0, 0.9, 0)
										: new UDim2(1, 0, 1, 0),
									Position: this.equalTo(weapon)
										? new UDim2(0, 0, -0.333, 0)
										: new UDim2(0, 0, 0, 0),
									BackgroundTransparency: 1,
								}}
							/>
							{this.equalTo(weapon) ? (
								<frame
									Size={new UDim2(1, 0, 0, 36)}
									Position={new UDim2(0, 0, 1, -36)}
									BackgroundTransparency={1}
								>
									<uigridlayout
										CellPadding={new UDim2(0, 5, 0, 5)}
										CellSize={new UDim2(0.333, 0, 1, 0)}
										FillDirection={"Horizontal"}
										SortOrder={"LayoutOrder"}
										StartCorner={"TopRight"}
										HorizontalAlignment={"Center"}
										VerticalAlignment={"Bottom"}
									/>
									<textlabel
										Font={"RobotoMono"}
										FontFace={new Font("RobotoMono", Enum.FontWeight.Bold)}
										Text={tostring(weapon.clip)}
										TextColor3={Colors.primary}
										TextScaled
										TextXAlignment={"Right"}
										TextYAlignment={"Bottom"}
										BackgroundTransparency={1}
										LayoutOrder={0}
									/>
									<textlabel
										Font={"RobotoMono"}
										Text={tostring(weapon.reserveAmmo)}
										TextColor3={Colors.primary}
										TextTransparency={0.4}
										TextScaled
										TextXAlignment={"Center"}
										TextYAlignment={"Bottom"}
										BackgroundTransparency={1}
										LayoutOrder={-1}
									/>
								</frame>
							) : (
								<></>
							)}
						</Frame>
					))}
				</frame>
			</Frame>
		);
	}
}
