import { DefaultPalette } from "@rbxts/commander";
import React, { Component, ReactComponent, type ReactNode } from "@rbxts/react";
import { Frame } from "./commander-styled/frame";

interface StaminaBarProps {
	max: number;
	current: number;
}

// 1
function returnColorByRatio(percentage: number) {
	if (percentage < 1) {
		return Color3.fromHex("#70FF00");
	}
	if (percentage <= 0.5) {
		return Color3.fromHex("#FFD600");
	}
	return Color3.fromHex("#FF1F00");
}

function calculateRatio(a: number, b: number) {
	return a / b;
}

@ReactComponent
export class StaminaBar extends Component<StaminaBarProps, {}> {
	componentDidMount(): void {}

	render(): ReactNode {
		return (
			<Frame
				cornerRadius={new UDim(0, 4)}
				size={new UDim2(0.2, 0, 0.05, 0)}
				anchorPoint={new Vector2(0.5, 0)}
				position={new UDim2(0.5, 0, 0.9, 0)}
				backgroundColor={DefaultPalette.frappe.background}
				backgroundTransparency={0.2}
				clipsDescendants={true}
			>
				<Frame
					cornerRadius={new UDim(0, 0)}
					size={new UDim2(1, -8, 0.5, 0)}
					position={new UDim2(0, 4, 0.25, 0)}
					backgroundTransparency={0}
					backgroundColor={DefaultPalette.frappe.background}
				>
					<Frame
						cornerRadius={new UDim(0, 0)}
						size={
							new UDim2(
								math.max(calculateRatio(this.props.current, this.props.max)),
								0,
								1,
								0,
							)
						}
						backgroundTransparency={0}
						backgroundColor={returnColorByRatio(
							math.max(calculateRatio(this.props.current, this.props.max), 0),
						)}
					/>
				</Frame>
			</Frame>
		);
	}
}
