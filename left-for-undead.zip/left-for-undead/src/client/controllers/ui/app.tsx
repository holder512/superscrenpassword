import React, {
	Component,
	ReactComponent,
	ReactNode,
	useState,
} from "@rbxts/react";
import { ReflexProvider } from "@rbxts/react-reflex";
import { type ClientState, clientState } from "client/state";
import { WeaponDataKey } from "shared/data/weapons";
import { Cursor } from "shared/ui/cursor";
import { Hud, transformForHUD } from "shared/ui/hud/hud";
import { HudWeaponViewport } from "shared/ui/hud/hud-weapon-viewport";
import { StaminaBar } from "shared/ui/stamina-bar";
import { DebugUI } from "./debug";

export function App() {
	const [stamina, setStamina] = useState(clientState.getState().stamina);
	const [weapons, setWeapons] = useState(clientState.getState().weapons);
	const [currentlySelectedWeapon, setCurrentlySelectedWeapon] = useState(
		clientState.getState().currentWeaponId,
	);

	// State Selectors

	const selectStamina = (state: ClientState) => {
		return state.stamina;
	};

	const selectWeapon = (state: ClientState) => {
		return state.currentWeaponId;
	};

	const selectWeapons = (state: ClientState) => {
		return state.weapons;
	};

	// Events

	clientState.subscribe(selectStamina, (state) => {
		setStamina(state);
	});

	clientState.subscribe(selectWeapons, (state) => {
		setWeapons(state);
	});

	clientState.subscribe(selectWeapon, (state) => {
		setCurrentlySelectedWeapon(state);
	});

	return (
		<ReflexProvider producer={clientState}>
			<Cursor
				crossSize={15}
				crossWidth={1}
				gap={4}
				dotSize={2}
				color={new Color3(0, 1, 0)}
			/>
			{/* <StaminaBar max={100} current={math.max(stamina, 0)} /> */}
			<Hud
				weapons={transformForHUD(weapons)}
				currentlySelectedWeapon={currentlySelectedWeapon}
			/>
			<DebugUI />
		</ReflexProvider>
	);
}
