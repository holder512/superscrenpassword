import React, { StrictMode, useState } from "@rbxts/react";

import { Controller, type OnStart } from "@flamework/core";

import { Players } from "@rbxts/services";

import { createRoot } from "@rbxts/react-roblox";

import Make from "@rbxts/make";
import { ReflexProvider, useProducer } from "@rbxts/react-reflex";
import { ClientState, clientState } from "client/state";
import { Cursor } from "shared/ui/cursor";
import { StaminaBar } from "shared/ui/stamina-bar";
import { App } from "./app";

@Controller({})
export class UiController implements OnStart {
	onStart() {
		print("[CLIENT] Controller/UiController: Started!");

		const rootInstance = Make("ScreenGui", {
			Name: "React_Managed_UI",
			IgnoreGuiInset: true,
			Parent: Players.LocalPlayer.WaitForChild("PlayerGui"),
		});

		const root = createRoot(rootInstance);

		root.render(
			<StrictMode>
				<App />
			</StrictMode>,
		);
	}
}
