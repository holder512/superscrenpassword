import type { Components } from "@flamework/components";
import { Controller, type OnStart } from "@flamework/core";
import { Dependency } from "@flamework/core";
import { Players, Workspace } from "@rbxts/services";
import { type ClientState, clientState } from "client/state";
import type { Viewmodel } from "shared/components/viewmodel";

@Controller({})
export class ViewmodelController implements OnStart {
	onStart() {
		while (typeOf(Players.LocalPlayer) !== "Instance") wait();

		const components = Dependency<Components>();
		let component = components.addComponent<Viewmodel>(Players.LocalPlayer);

		const selectWeapon = (state: ClientState) => {
			return state.currentWeaponId;
		};

		clientState.subscribe(selectWeapon, (currentWeapon) => {
			components.removeComponent<Viewmodel>(Players.LocalPlayer);
			Workspace.CurrentCamera?.ClearAllChildren();
			component = components.addComponent<Viewmodel>(Players.LocalPlayer);
			component.switchWeapon(currentWeapon);
			component.start();
		});
	}
}
