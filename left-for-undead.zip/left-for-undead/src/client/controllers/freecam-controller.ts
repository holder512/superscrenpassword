import { Controller, type OnStart } from "@flamework/core";
import { ReplicatedStorage } from "@rbxts/services";
import { Events } from "client/network";
import { startFreeCamera, stopFreeCamera } from "./freecam/toggle";

@Controller()
export class FreecamController implements OnStart {
	onStart(): void {
		const event = ReplicatedStorage.WaitForChild("freecam") as RemoteEvent;

		event.OnClientEvent.Connect((state: boolean) => {
			if (state) {
				startFreeCamera();
			} else {
				stopFreeCamera();
			}
		});
	}
}
