import { Controller, OnInit, type OnStart } from "@flamework/core";
import BloxstrapRPC from "@rbxts/bloxstrap-rpc-sdk";

import { Players } from "@rbxts/services";

@Controller({})
export class BloxstrapController implements OnStart {
	onStart() {
		const startTimestamp = os.time();

		Players.PlayerAdded.Connect(() => {
			BloxstrapRPC.SetRichPresence({
				details: "Left for Undead",
				state: `Playing Survival (${Players.GetPlayers().size()}/4)`,
				timeStart: startTimestamp,
				largeImage: {
					assetId: 13409122839,
					hoverText: "Left for Undead",
				},
				smallImage: {
					assetId: 17787157803,
					hoverText: "by Shrunk Slain",
				},
			});
		});

		Players.PlayerRemoving.Connect(() => {
			BloxstrapRPC.SetRichPresence({
				details: "Left for Undead",
				state: `Playing Survival (${Players.GetPlayers().size()}/4)`,
				timeStart: startTimestamp,
				largeImage: {
					assetId: 13409122839,
					hoverText: "Left for Undead",
				},
				smallImage: {
					assetId: 17787157803,
					hoverText: "by Shrunk Slain",
				},
			});
		});

		BloxstrapRPC.SetRichPresence({
			details: "Left for Undead",
			state: `Playing Survival (${Players.GetPlayers().size()}/4)`,
			timeStart: startTimestamp,
			largeImage: {
				assetId: 13409122839,
				hoverText: "Left for Undead",
			},
			smallImage: {
				assetId: 17787157803,
				hoverText: "by Shrunk Slain",
			},
		});

		print("[CLIENT] Controller/BloxstrapController: Started!");
	}
}
