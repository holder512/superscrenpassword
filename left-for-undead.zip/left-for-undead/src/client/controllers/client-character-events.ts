import { Controller, type OnStart } from "@flamework/core";
import { Players } from "@rbxts/services";
import { Workspace } from "@rbxts/services";
import { Events } from "client/network";

@Controller({})
export class ClientCharacterEvents implements OnStart {
	onStart() {
		Events.character.initialize.connect(() => {
			Workspace.CurrentCamera!.CameraSubject =
				Players.LocalPlayer.Character?.WaitForChild("Head") as BasePart;

			Players.LocalPlayer.Character?.GetDescendants().forEach((instance) => {
				if (instance.IsA("BasePart")) {
					instance.LocalTransparencyModifier = 1;
				}
			});
		});
	}
}
