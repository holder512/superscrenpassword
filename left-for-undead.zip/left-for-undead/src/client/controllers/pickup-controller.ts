import type { Components } from "@flamework/components";
import {
	Controller,
	Dependency,
	Modding,
	OnInit,
	type OnStart,
} from "@flamework/core";
import { Players, Workspace } from "@rbxts/services";
import { Events, Functions } from "client/network";
import { clientState } from "client/state";
import type { Pickup } from "shared/components/pickup";
import {
	PickupData,
	type PickupDataKey,
	PickupType,
} from "shared/data/pickups";
import { WeaponData } from "shared/data/weapons";

/**
 * @name PickupController
 * @description Handles pickup objects.
 * @controller
 */
@Controller({})
export class PickupController implements OnStart {
	private character: Model | undefined;
	private pickupObjects: Array<BasePart> = [];

	onStart() {
		print("[CLIENT] Controller/PickupController: Started!");

		// Get the character while making sure it's not undefined.
		while (typeOf(Players.LocalPlayer) !== "Instance") task.wait();

		this.character = Players.LocalPlayer.Character;

		// Handle adding and removing of pickup objects.
		Workspace.WaitForChild("Pickups").ChildAdded.Connect((child) => {
			this.addObjects();
			this.registerTouchListeners();
		});

		Workspace.WaitForChild("Pickups").ChildRemoved.Connect((child) => {
			this.addObjects();
			this.registerTouchListeners();
		});
	}

	addObjects() {
		this.pickupObjects = [];
		Workspace.WaitForChild("Pickups")
			.GetChildren()
			.forEach((child) => {
				this.pickupObjects.push(child as BasePart);
			});
	}

	registerTouchListeners() {
		this.pickupObjects.forEach((object) => {
			object.Touched.Connect((part) => {
				if (
					Players.GetPlayerFromCharacter(part.Parent) === Players.LocalPlayer
				) {
					this.handlePickup(object as unknown as BasePart);
				}
			});
		});
	}

	handlePickup(pickupObject: BasePart) {
		const components = Dependency<Components>();

		// Get the pickup component
		const pickupComponent = components.getComponent<Pickup>(pickupObject);

		const pickupData = PickupData.find((value) => {
			return value.id === pickupComponent?.attributes.id;
		}) as PickupDataKey;

		print(pickupComponent?.attributes.id);
		print(pickupData);

		const state = clientState.getState();

		const currentWeaponIndex = state.weapons.findIndex((value) => {
			return value.id === state.currentWeaponId;
		});

		//!TODO Extrapolate logic to seperate functions.
		pickupData.gives.forEach((gives) => {
			if (gives.type === PickupType.AMMO) {
				clientState.setWeapon({
					ammo: state.weapons[currentWeaponIndex].ammo,
					reserveAmmo: math.min(
						state.weapons[currentWeaponIndex].ammo + gives.params.quantity!,
						WeaponData[state.currentWeaponId].ammo,
					),
					id: state.currentWeaponId,
				});
			} else if (gives.type === PickupType.HEALTH) {
				clientState.setHealth(
					math.min(state.health + gives.params.quantity!, state.maxHealth),
				);
			} else if (gives.type === PickupType.WEAPON) {
				clientState.addWeapon({
					ammo: WeaponData[gives.params.weaponId!].clipSize,
					reserveAmmo: WeaponData[gives.params.weaponId!].ammo,
					id: gives.params.weaponId!,
				});
			}
		});

		Events.removePickup.fire(pickupObject);
	}
}
