import { Controller, OnInit, type OnStart, type OnTick } from "@flamework/core";
import { useKeyPress } from "@rbxts/pretty-react-hooks";
import { Players, UserInputService } from "@rbxts/services";
import { clientState } from "client/state";

//!TODO: Refactor sprinting -> walking
@Controller({})
export class MovementController implements OnStart, OnTick {
	private sprinting = false;

	onStart() {
		print("[CLIENT] Controller/MovementController: Started!");

		UserInputService.InputBegan.Connect((input) => {
			if (
				input.KeyCode === Enum.KeyCode.RightShift ||
				input.KeyCode === Enum.KeyCode.LeftShift
			) {
				this.sprinting = true;
				clientState.setSprinting(true);
			}
		});

		UserInputService.InputEnded.Connect((input) => {
			if (
				input.KeyCode === Enum.KeyCode.RightShift ||
				input.KeyCode === Enum.KeyCode.LeftShift
			) {
				this.sprinting = false;
				clientState.setSprinting(false);
			}
		});
	}

	onTick(deltaTime: number) {
		if (this.sprinting) {
			// clientState.setStamina(clientState.getState().stamina - 0.5);
			if (clientState.getState().stamina > 0) {
				if (Players.LocalPlayer.Character !== undefined) {
					(
						Players.LocalPlayer.Character?.WaitForChild("Humanoid") as Humanoid
					).WalkSpeed = 4;
				}
			}
		} else {
			if (Players.LocalPlayer.Character !== undefined) {
				(
					Players.LocalPlayer.Character?.WaitForChild("Humanoid") as Humanoid
				).WalkSpeed = 16;
			}
		}

		// Regenerate stamina / time.
		// if (!this.sprinting) {
		// 	clientState.setStamina(math.min(clientState.getState().stamina + 0.125, clientState.getState().maxStamina));
		// }
	}
}
