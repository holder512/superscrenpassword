import { GlobalEvents, GlobalFunctions } from "shared/network";

export const Events = GlobalEvents.createClient({});
export const Functions = GlobalFunctions.createClient({});
