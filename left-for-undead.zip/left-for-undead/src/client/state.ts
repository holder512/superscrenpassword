import { ObjectUtil } from "@rbxts/commander/out/shared/util/data";
import { number } from "@rbxts/react/src/prop-types";
import { createProducer } from "@rbxts/reflex";
import { WeaponData, WeaponDataKey } from "shared/data/weapons";

export interface ClientState {
	stamina: number;
	maxStamina: number;
	sprinting: boolean;
	weapons: Array<{
		ammo: number;
		reserveAmmo: number;
		id: string;
	}>;
	currentWeaponId: string;
	health: number;
	maxHealth: number;
}

const initialState: ClientState = {
	stamina: 100,
	maxStamina: 100,
	sprinting: false,
	weapons: [
		{
			ammo: WeaponData.pistol.clipSize,
			reserveAmmo: WeaponData.pistol.ammo,
			id: "pistol",
		},
		{
			ammo: WeaponData.uzi.clipSize,
			reserveAmmo: WeaponData.uzi.ammo,
			id: "uzi",
		},
	],
	currentWeaponId: "pistol",
	health: 150,
	maxHealth: 150,
};

export const clientState = createProducer(initialState, {
	setStamina: (state, stamina: number) => ({
		...state,
		stamina: stamina,
	}),
	setMaxStamina: (state, stamina: number) => ({
		...state,
		maxStamina: stamina,
	}),
	setSprinting: (state, sprinting: boolean) => {
		const newState: ClientState = {
			...state,
			sprinting: sprinting,
		};

		if (sprinting) {
			// Decrease stamina here
			newState.stamina = math.max(0, newState.stamina); // adjust the stamina decrease rate as needed
		}

		return newState;
	},
	setWeapon: (
		state,
		weapon: {
			ammo: number;
			reserveAmmo: number;
			id: string;
		},
	) => {
		const newWeaponsArray: Array<{
			ammo: number;
			reserveAmmo: number;
			id: string;
		}> = [];

		const weapons = state.weapons;

		weapons.forEach((value, index) => {
			if (value.id === weapon.id) {
				newWeaponsArray.push({
					ammo: weapon.ammo,
					reserveAmmo: weapon.reserveAmmo,
					id: weapon.id,
				});
			} else {
				newWeaponsArray.push(value);
			}
		});

		return {
			...state,
			weapons: newWeaponsArray,
		};
	},
	decrementAmmo: (state) => {
		const weapons = state.weapons;

		const weaponIndex = weapons.findIndex((value) => {
			return value.id === state.currentWeaponId;
		});

		weapons[weaponIndex] = {
			...weapons[weaponIndex],
			ammo: weapons[weaponIndex].ammo - 1,
		};

		return {
			...state,
			weapons: weapons,
		};
	},
	setCurrentWeapon: (state, index: string) => ({
		...state,
		currentWeaponId: index,
	}),
	setHealth: (state, health: number) => ({
		...state,
		health: health,
	}),
	setMaxHealth: (state, maxHealth: number) => ({
		...state,
		maxHealth: maxHealth,
	}),
	addWeapon: (
		state,
		weapon: {
			ammo: number;
			reserveAmmo: number;
			id: string;
		},
	) => {
		const newWeaponsArray = state.weapons;

		newWeaponsArray.push(weapon);

		return {
			...state,
			weapons: newWeaponsArray,
		};
	},
});
