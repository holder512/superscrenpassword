import { createProducer } from "@rbxts/reflex";

export type ServerState = {};

const initialServerState: ServerState = {};

export const state = createProducer(initialServerState, {});
