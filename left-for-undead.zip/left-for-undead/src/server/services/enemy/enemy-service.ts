import { type OnStart, Service } from "@flamework/core";
import { state } from "shared/state";

@Service()
export class EnemyService implements OnStart {
	onStart(): void {
		print("Service/Enemy/EnemyService: Started!");

		state.subscribe(
			(state) => {
				return state.enemies;
			},
			(enemies) => {},
		);
	}
}
