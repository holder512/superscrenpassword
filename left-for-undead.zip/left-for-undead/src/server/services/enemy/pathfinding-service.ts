import { type OnStart, Service } from "@flamework/core";
import { Debris, PathfindingService, Workspace } from "@rbxts/services";

import {
	Command,
	type CommandContext,
	Commander,
	CommanderType,
	Guard,
} from "@rbxts/commander";
import { isTester } from "shared/guards";

@Commander({
	globalGroups: ["pathfinding"],
})
@Service()
export class EnemyPathfindingService implements OnStart {
	/**
	 * @name requestPath
	 * @description Calculates a path from a model's PivotPoint to a given CFrame goal.
	 * @param modelPivotPoint
	 * @param goal
	 * @param [agentParameters={}]
	 */
	public requestPath(
		modelPivotPoint: Vector3,
		goal: CFrame,
		agentParameters: Partial<AgentParameters> = {},
	): Array<PathWaypoint> {
		const path = PathfindingService.CreatePath({
			AgentCanClimb: true,
			AgentCanJump: true,
			...agentParameters,
		});

		path.ComputeAsync(modelPivotPoint, goal.Position);

		if (path.Status !== Enum.PathStatus.Success) {
			warn(`PathfindingService: Pathfinding failed: ${path.Status}`);
			return [];
		}

		return path.GetWaypoints();
	}

	/**
	 * @name followPath
	 * @description Takes in a model with a Humanoid and makes the Humanoid follow the waypoints.
	 * @param model
	 * @param waypoints
	 */
	private async followPath(
		model: Model & { Humanoid: Humanoid },
		waypoints: Array<PathWaypoint>,
	) {
		for (const waypoint of waypoints) {
			if (waypoint.Action === Enum.PathWaypointAction.Jump) {
				model.Humanoid.Jump = true;
				// Wait a short time to ensure the jump action is registered
				task.wait(0.1);
				model.Humanoid.Jump = false;
			}

			model.Humanoid.MoveTo(waypoint.Position);

			// Wait for the humanoid to reach the waypoint
			const reached = model.Humanoid.MoveToFinished.Wait();
			if (!reached[0]) {
				warn(
					`PathfindingService: Failed to reach waypoint: ${waypoint.Position}`,
				);
				break;
			}
		}
	}

	private recomputePath(
		model: Model & { HumanoidRootPart: BasePart; Humanoid: Humanoid },
		goal: CFrame,
	) {
		const waypoints = this.requestPath(model.HumanoidRootPart.Position, goal);
		if (waypoints.size() > 0) {
			this.followPath(model, waypoints);
		}
	}

	private visualizePath(waypoints: Array<PathWaypoint>, expire: number) {
		const point = new Instance("Part");

		point.Size = new Vector3(0.5, 0.5, 0.5);
		point.Shape = Enum.PartType.Ball;
		point.Material = Enum.Material.Neon;
		// point.Transparency = 0.7;
		point.Anchored = true;

		for (const waypoint of waypoints) {
			if (waypoint.Action === Enum.PathWaypointAction.Jump) {
				const newPoint = point.Clone();
				newPoint.Color = Color3.fromRGB(255, 0, 0);
				newPoint.Parent = Workspace;
				newPoint.Position = waypoint.Position;
				Debris.AddItem(newPoint, expire);
			} else {
				const newPoint = point.Clone();
				newPoint.Color = Color3.fromRGB(255, 255, 0);
				newPoint.Parent = Workspace;
				newPoint.Position = waypoint.Position;
				Debris.AddItem(newPoint, expire);
			}
		}
	}

	@Command({
		name: "pathfinding.visualize",
		description: "Pathfind from A to B",
		arguments: [
			{
				name: "pos1",
				description: "The first position",
				type: "vector",
			},
			{
				name: "pos2",
				description: "The second position",
				type: "vector",
			},
			{
				name: "canClimb",
				description: "Can the agent climb?",
				type: CommanderType.Boolean,
			},
			{
				name: "canJump",
				description: "Can the agent climb?",
				type: CommanderType.Boolean,
			},
		],
	})
	@Guard(isTester)
	public visualizeCommand(
		context: CommandContext,
		pos1: Vector3,
		pos2: Vector3,
		canClimb: boolean,
		canJump: boolean,
	) {
		print(
			`Command/Pathfinding/Visualize: ${context.executor?.DisplayName} has requested a visualization!`,
		);
		const waypoints = this.requestPath(pos1, new CFrame(pos2), {
			AgentCanClimb: canClimb || true,
			AgentCanJump: canJump || true,
		});
		this.visualizePath(waypoints, 10);
	}

	onStart(): void {
		print("Service/Enemy/PathfindingService: Started!");
	}
}
