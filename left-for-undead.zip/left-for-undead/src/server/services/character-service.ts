import { type OnStart, Service } from "@flamework/core";
import { Players, ReplicatedStorage, Teams, Workspace } from "@rbxts/services";
import { Events } from "server/network";
import { Character } from "shared/types/default-character";
import type { PlayerTeam } from "shared/types/player-team";
import {
	Survivor,
	SurvivorStats,
	type SurvivorStatsKey,
} from "shared/types/survivor";

/**
 * @name CharacterService
 * @description Handles character management
 */
@Service()
export class CharacterService implements OnStart {
	getModelFromName(name: Survivor) {
		switch (name) {
			case Survivor.Bill:
				return ReplicatedStorage.WaitForChild("WorldModels")
					.WaitForChild("Characters")
					.WaitForChild("Bill");
				break;
			case Survivor.Francis:
				return ReplicatedStorage.WaitForChild("WorldModels")
					.WaitForChild("Characters")
					.WaitForChild("Francis");
				break;
			case Survivor.Louis:
				return ReplicatedStorage.WaitForChild("WorldModels")
					.WaitForChild("Characters")
					.WaitForChild("Louis");
				break;
			case Survivor.Zoey:
				return ReplicatedStorage.WaitForChild("WorldModels")
					.WaitForChild("Characters")
					.WaitForChild("Zoey");
				break;
			case Survivor.Coach:
				return ReplicatedStorage.WaitForChild("WorldModels")
					.WaitForChild("Characters")
					.WaitForChild("Coach");
				break;
			case Survivor.Nick:
				return ReplicatedStorage.WaitForChild("WorldModels")
					.WaitForChild("Characters")
					.WaitForChild("Nick");
				break;
			case Survivor.Ellis:
				return ReplicatedStorage.WaitForChild("WorldModels")
					.WaitForChild("Characters")
					.WaitForChild("Ellis");
				break;
			case Survivor.Rochelle:
				return ReplicatedStorage.WaitForChild("WorldModels")
					.WaitForChild("Characters")
					.WaitForChild("Rochelle");
				break;
		}
	}

	getSurvivorFromString(name: string) {
		switch (name) {
			case "Bill":
				return Survivor.Bill;
				break;
			case "Francis":
				return Survivor.Francis;
				break;
			case "Louis":
				return Survivor.Louis;
				break;
			case "Zoey":
				return Survivor.Zoey;
				break;
			case "Coach":
				return Survivor.Coach;
				break;
			case "Nick":
				return Survivor.Nick;
				break;
			case "Ellis":
				return Survivor.Ellis;
				break;
			case "Rochelle":
				return Survivor.Rochelle;
				break;
			default:
				return Survivor.Coach;
				break;
		}
	}

	change(player: Player, team: PlayerTeam, name: string): number {
		player.Team = Teams.GetTeams().find((value) => {
			return value.Name === team;
		});

		if (team === "Survivor") {
			const Data = SurvivorStats.filter((value) => {
				return value.name === name;
			})[0];
			const Model = this.getModelFromName(
				this.getSurvivorFromString(name),
			) as Model;

			Data!.taken = true;

			if (player.Character) {
				Model.PivotTo(player.Character.GetPivot());

				player.Character.Destroy();
				player.Character = undefined;
			}

			Model.Name = player.Name;
			Model.Parent = Workspace;

			player.Character = Model;

			Model.PrimaryPart!.Anchored = false;
			const Humanoid = Model.WaitForChild("Humanoid") as Humanoid;
			Humanoid.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None;

			Humanoid.WalkSpeed = Data?.speed;
			Humanoid.MaxHealth = Data?.health;
			Humanoid.Health = Data?.health;
			Humanoid.JumpPower = Data?.jumpPower;

			Humanoid.FindFirstChild("Animator")
				? new Instance("Animator", Humanoid)
				: undefined;

			Events.character.initialize.fire(player);

			return 0;
		}
		return 1; // Not an error, but unexpected behavior
	}

	findAvailableSurvivor(requestedSurvivor: keyof Survivor) {
		//  Check if the chosen character is taken
		SurvivorStats.forEach((survivor: SurvivorStatsKey) => {
			if (survivor.name === requestedSurvivor && !survivor.taken)
				return survivor;
		});

		SurvivorStats.forEach((survivor) => {
			//!TODO Implement this
			// if (!survivor.survivor) {continue};
			if (!survivor.taken) return survivor;
		});
	}

	onStart(): void {
		print("Service/CharacterService: Started!");
	}
}
