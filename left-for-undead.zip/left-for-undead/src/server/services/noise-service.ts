import { type OnStart, Service } from "@flamework/core";
import { Workspace } from "@rbxts/services";
import { Events } from "server/network";
import { sounds } from "shared/data/sounds";

@Service({})
export class NoiseService implements OnStart {
	public playNoise(id: string, volume?: number, origin?: Vector3) {
		const sound = new Instance("Sound");

		sound.Parent = Workspace;
		sound.Volume = volume !== undefined ? volume : 10;
		const soundData = sounds.find((value) => value.name === id);
		if (soundData) {
			sound.SoundId = soundData.id;
		} else {
			warn(`Sound with id ${id} not found`);
		}
		sound.Play();

		sound.Ended.Once(() => {
			sound.Destroy();
		});
	}

	onStart() {
		Events.environment.playSound.connect((player, id, origin, volume) => {
			this.playNoise(id, volume, origin);
		});
		print("Service/NoiseService: Started!");
	}
}
