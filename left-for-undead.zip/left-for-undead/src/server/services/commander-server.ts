import { CommanderServer, TransformResult, TypeBuilder } from "@rbxts/commander";
import { t } from "@rbxts/t";
import { EnemyData } from "shared/data/enemies";
import { sounds } from "shared/data/sounds";

import { commanderEnemyIdType } from "shared/types/commander/enemy-id";
import { commanderPickupIdType } from "shared/types/commander/pickup-id";
import { commanderSoundIdType } from "shared/types/commander/sound-id";
import { commanderVector3Type } from "shared/types/commander/vector-type";

CommanderServer.start((registry) => {
	registry.registerType(commanderEnemyIdType);
	registry.registerType(commanderSoundIdType);
	registry.registerType(commanderVector3Type);
	registry.registerType(commanderPickupIdType);
	registry.registerCommands();
}).catch((err) => {
	warn(`Commander couldn't be started: ${tostring(err)!}`);
});
