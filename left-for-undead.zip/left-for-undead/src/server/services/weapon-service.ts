import { type OnStart, Service } from "@flamework/core";
import { Events } from "server/network";

@Service({})
export class WeaponService implements OnStart {
	onStart() {
		print("Service/WeaponService: Started!");
		Events.weapon.fire.connect((player, bulletType, origin, hit) => {
			Events.weapon.fireVisual.broadcast(player, bulletType, origin, hit);
		});
	}
}
