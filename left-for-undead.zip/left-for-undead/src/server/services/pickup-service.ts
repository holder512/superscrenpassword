import { OnInit, type OnStart, Service } from "@flamework/core";
import { Events } from "server/network";

@Service({})
export class PickupService implements OnStart {
	onStart() {
		print("Service/PickupService: Started!");

		Events.removePickup.connect((player, object) => {
			object.Destroy();
		});
	}
}
