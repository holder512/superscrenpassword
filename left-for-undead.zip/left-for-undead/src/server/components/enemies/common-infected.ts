import { Component } from "@flamework/components";
import type { OnStart } from "@flamework/core";
import { BaseEnemyComponent } from "../base-enemy";

@Component({
	tag: "enemy.common-infected",
})
export class CommonInfectedEnemy extends BaseEnemyComponent implements OnStart {
	private targetPosition: CFrame | undefined;

	onStart(): void {
		this.attributes.id = "common-infected";
	}
}
