import { Component } from "@flamework/components";
import {
	Command,
	type CommandContext,
	Commander,
	Guard,
} from "@rbxts/commander";
import { HttpService } from "@rbxts/services";
import { isAdmin } from "shared/guards";
import { state } from "shared/state";

@Commander()
@Component()
export class PrintStateCommand {
	@Command({
		name: "debug.printstate",
		description: "Writes the value of the shared state object.",
	})
	@Guard(isAdmin)
	public async run(context: CommandContext) {
		let reply = "";

		for (const [key, value] of pairs(state.getState())) {
			if (type(value) === "table") {
				reply += "--- TABLE ---\n";
				reply += `[${key}]:${HttpService.JSONEncode(value)}\n`;
			} else {
				reply += `[${key}]: ${value}\n`;
			}
		}

		context.reply(reply);
	}
}
