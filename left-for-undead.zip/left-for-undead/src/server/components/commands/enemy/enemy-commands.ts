import { BaseComponent, Component } from "@flamework/components";
import {
	Command,
	type CommandContext,
	Commander,
	CommanderType,
	Guard,
	TransformResult,
	TypeBuilder,
} from "@rbxts/commander";

import { OnStart } from "@flamework/core";
import { EnemyData } from "shared/data/enemies";
import { isAdmin } from "shared/guards";
import { state } from "shared/state";

@Commander({})
@Component()
export class EnemyCommand extends BaseComponent {
	@Command({
		name: "enemy.spawn",
		description: "Spawns an enemy",
		arguments: [
			{
				name: "enemyId",
				type: "enemyid",
				description: "The id of the enemy to spawn",
			},
			{
				name: "position",
				type: "vector",
				description: "The position of where to spawn the enemies",
			},
			{
				name: "count",
				type: CommanderType.Integer,
				description: "How many enemies to spawn",
				optional: true,
			},
		],
	})
	@Guard(isAdmin)
	spawnEnemy(
		context: CommandContext,
		id: string,
		position: Vector3,
		count: number,
	) {
		const enemy = EnemyData.find((enemy) => enemy.id === id);

		print(
			`Command/Enemy/Spawn: ${context.executor?.DisplayName} has requested to spawn ${
				count !== undefined ? count : 1
			} ${id} enemy(ies)!`,
		);

		state.addEnemy({
			id: enemy?.id,
			cFrame: new CFrame(position),
			playingAnimations: [],
		});

		context.reply(
			`Spawned ${count !== undefined ? count : 1} ${id} enemy(ies)!`,
		);
	}

	@Command({
		name: "enemy.remove",
		description: "",
		arguments: [],
	})
	@Guard(isAdmin)
	removeAllEnemies(context: CommandContext) {
		state.setState({
			...state.getState(),
			enemies: new Set(),
		});

		context.reply("Removed all enemies!");
	}
}
