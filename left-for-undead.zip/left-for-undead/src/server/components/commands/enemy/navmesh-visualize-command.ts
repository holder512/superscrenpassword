import { OnStart, Service } from "@flamework/core";
import {
	Command,
	type CommandContext,
	Commander,
	CommanderType,
	Guard,
} from "@rbxts/commander";
import { Debris, PathfindingService, Workspace } from "@rbxts/services";
import { isTester } from "shared/guards";

@Commander()
@Service()
export class NavmeshVisualizer {
	private createNode(position: Vector3, color: Color3, size: number) {
		const node = new Instance("Part");
		node.Size = new Vector3(size, size, size);
		node.Shape = Enum.PartType.Ball;
		node.Material = Enum.Material.Neon;
		node.Color = color;
		node.Anchored = true;
		node.CanCollide = false;
		node.Position = position;
		node.Parent = Workspace;
		return node;
	}

	private createConnection(start: Vector3, stop: Vector3, color: Color3) {
		const distance = start.sub(stop).Magnitude;
		const midpoint = start.Lerp(stop, 0.5);
		const connection = new Instance("Part");
		connection.Size = new Vector3(0.2, 0.2, distance);
		connection.Material = Enum.Material.Neon;
		connection.Color = color;
		connection.Anchored = true;
		connection.CanCollide = false;
		connection.CFrame = CFrame.lookAt(midpoint, stop);
		connection.Parent = Workspace;
		return connection;
	}

	private visualizeNavmesh(waypoints: Array<PathWaypoint>, expire: number) {
		const nodeColor = Color3.fromRGB(0, 255, 0);
		const connectionColor = Color3.fromRGB(255, 255, 0);

		for (let i = 0; i < waypoints.size() - 1; i++) {
			const currentWaypoint = waypoints[i];
			const nextWaypoint = waypoints[i + 1];

			const node = this.createNode(currentWaypoint.Position, nodeColor, 0.5);
			Debris.AddItem(node, expire);

			const connection = this.createConnection(
				currentWaypoint.Position,
				nextWaypoint.Position,
				connectionColor,
			);
			Debris.AddItem(connection, expire);
		}

		// Visualize the last waypoint node
		const lastNode = this.createNode(
			waypoints[waypoints.size() - 1].Position,
			nodeColor,
			0.5,
		);
		Debris.AddItem(lastNode, expire);
	}

	@Command({
		name: "navmesh.visualize",
		description: "Visualize navmesh from A to B",
		arguments: [
			{
				name: "pos1",
				description: "The first position",
				type: "vector",
			},
			{
				name: "pos2",
				description: "The second position",
				type: "vector",
			},
			{
				name: "expires",
				description: "When the visualization expires",
				type: CommanderType.Number,
				optional: true,
			},
		],
	})
	@Guard(isTester)
	public visualizeCommand(
		context: CommandContext,
		pos1: Vector3,
		pos2: Vector3,
		expires: number,
	) {
		print(
			`Command/Navmesh/Visualize: ${context.executor?.DisplayName} has requested a visualization!`,
		);
		const path = PathfindingService.CreatePath({
			AgentCanClimb: true,
			AgentCanJump: true,
		});

		path.ComputeAsync(pos1, pos2);

		if (path.Status === Enum.PathStatus.Success) {
			const waypoints = path.GetWaypoints();
			this.visualizeNavmesh(waypoints, expires !== undefined ? expires : 10);
		} else {
			print("Pathfinding failed with status:", path.Status);
		}
	}
}
