import { BaseComponent, Component } from "@flamework/components";
import { OnStart, Service } from "@flamework/core";
import {
	Command,
	type CommandContext,
	Commander,
	Guard,
} from "@rbxts/commander";
import { ReplicatedStorage } from "@rbxts/services";
import { isAdmin, isTester } from "shared/guards";
import {
	startFreeCamera,
	stopFreeCamera,
} from "../../../../client/controllers/freecam/toggle";

@Commander()
@Component()
export class Freecam extends BaseComponent {
	enabled = false;

	@Command({
		name: "freecam",
		description: "Toggles free camera mode.",
		arguments: [],
	})
	@Guard(isTester)
	freecam(context: CommandContext) {
		this.enabled = !this.enabled;
		const event = ReplicatedStorage.WaitForChild("freecam") as RemoteEvent;

		event.FireClient(context.executor!, this.enabled);
	}
}
