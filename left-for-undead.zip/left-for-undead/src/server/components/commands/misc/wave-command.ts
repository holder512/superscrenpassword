import { Component } from "@flamework/components";
import { Command, type CommandContext, Commander, CommanderType, Guard } from "@rbxts/commander";
import { state } from "shared/state";

@Commander()
@Component()
export class WaveCommand {
	@Command({
		name: "setwave",
		description: "Set's the current wave",
		arguments: [
			{
				name: "wave",
				description: "The wave number",
				type: CommanderType.Integer,
			},
		],
	})
	@Guard()
	run(interaction: CommandContext, wave: number) {
		state.setWave(wave);
		interaction.reply(`Set the wave to: ${wave}!`);
	}
}
