import { Component, type Components } from "@flamework/components";
import { Dependency } from "@flamework/core";
import {
	Command,
	type CommandContext,
	Commander,
	Guard,
} from "@rbxts/commander";
import { ReplicatedStorage, Workspace } from "@rbxts/services";
import type { Pickup } from "shared/components/pickup";
import { PickupData } from "shared/data/pickups";
import { isAdmin } from "shared/guards";

@Commander()
@Component()
export class SpawnPickupCommand {
	constructor(private readonly pickup: Pickup) {}

	@Command({
		name: "spawnpickup",
		aliases: [],
		description: "Spawns a pickup component",
		arguments: [
			{
				name: "position",
				description: "Where the component should be placed.",
				type: "vector",
			},
			{
				name: "id",
				description: "The id of the pickup.",
				type: "pickupid",
			},
		],
	})
	@Guard(isAdmin)
	run(context: CommandContext, position: Vector3, id: string) {
		const model = ReplicatedStorage.WaitForChild("Client")
			.WaitForChild("Pickups")
			.WaitForChild(id)
			.Clone() as BasePart;

		const components = Dependency<Components>();

		const component = components.addComponent<Pickup>(model);

		model.Position = position;

		component.attributes.position = position;
		component.attributes.id = id;

		model.Parent = Workspace.WaitForChild("Pickups");

		context.reply(`Added a ${id} pickup at ${position}`);
	}
}
