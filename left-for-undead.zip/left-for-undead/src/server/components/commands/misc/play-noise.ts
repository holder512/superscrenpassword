import { BaseComponent, Component } from "@flamework/components";
import { Dependency, Modding, OnStart, Service } from "@flamework/core";
import {
	Command,
	type CommandContext,
	Commander,
	CommanderType,
	Guard,
} from "@rbxts/commander";
import { Workspace } from "@rbxts/services";
import type { NoiseService } from "server/services/noise-service";
import { sounds } from "shared/data/sounds";
import { isAdmin } from "shared/guards";

@Commander()
@Component()
export class PlayNoiseCommand extends BaseComponent {
	@Command({
		name: "playnoise",
		description: "Plays a noise in the index.",
		arguments: [
			{
				name: "id",
				description: "The noise's identifier.",
				type: "soundid",
			},
			{
				name: "volume",
				description: "The volume of the noise",
				type: CommanderType.Number,
			},
			{
				name: "origin",
				description: "Where the sound originated from",
				type: "vector",
				optional: true,
			},
		],
	})
	@Guard(isAdmin)
	run(context: CommandContext, id: string, volume: number, origin?: Vector3) {
		const noiseService = Dependency<NoiseService>();
		noiseService.playNoise(id, volume, origin);
		context.reply(
			`Played sound: ${id} with volume: ${volume} originating from: ${origin}`,
		);
	}
}
