import { BaseComponent, Component } from "@flamework/components";
import type { EnemyState } from "shared/types/enemy-state";

@Component()
export class BaseEnemyComponent extends BaseComponent<EnemyState> {}
