import { Controller, OnStart } from "@flamework/core";
import { Events } from "client/network";
import { clientState } from "client/state";

@Controller({})
export class DebugUiController implements OnStart {
	onStart() {
		Events.debug.showStateUI.connect(() => {
			clientState.setDebugStateMenuVisible(!clientState.getState().ui.debugStateMenuVisible);
		});

		print("[CLIENT] Controllers/DebugUiController: Started!");
	}
}
