import { Controller, OnStart } from "@flamework/core";
import { Events } from "client/network";
import { startFreeCamera, stopFreeCamera } from "./freecam/toggle";
import { ReplicatedStorage } from "@rbxts/services";

@Controller()
export class FreecamController implements OnStart {
	private enabled: boolean = false;

	onStart(): void {
		Events.toggleFreeCameraMode.connect(() => {
			this.enabled = !this.enabled;
			if (this.enabled) {
				startFreeCamera();
			} else {
				stopFreeCamera();
			}
		});
	}
}
