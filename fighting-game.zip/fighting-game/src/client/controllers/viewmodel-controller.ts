import { Controller, OnStart } from "@flamework/core";
import { Players, Workspace } from "@rbxts/services";
import { Dependency } from "@flamework/core";
import { Components } from "@flamework/components";
import { Viewmodel } from "shared/components/viewmodel";
import { ClientState, clientState } from "client/state";

@Controller({})
export class ViewmodelController implements OnStart {
	onStart() {
		while (typeOf(Players.LocalPlayer) !== "Instance") wait();

		const components = Dependency<Components>();
		let component = components.addComponent<Viewmodel>(Players.LocalPlayer);

		const selectWeapon = (state: ClientState) => {
			return state.currentWeaponId;
		};

		clientState.subscribe(selectWeapon, (currentWeapon) => {
			components.removeComponent<Viewmodel>(Players.LocalPlayer);
			Workspace.CurrentCamera?.ClearAllChildren();
			component = components.addComponent<Viewmodel>(Players.LocalPlayer);
			component.switchWeapon(currentWeapon);
			component.start();
		});
	}
}
