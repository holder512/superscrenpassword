import { Components } from "@flamework/components";
import { Controller, Dependency, Modding, OnStart } from "@flamework/core";
import Make from "@rbxts/make";
import { Debris, Players, ReplicatedStorage, TweenService, UserInputService, Workspace } from "@rbxts/services";
import { Events } from "client/network";
import { ClientState, clientState } from "client/state";
import { Viewmodel } from "shared/components/viewmodel";
import { ExternalAnimations } from "shared/data/external-animations";
import { ViewmodelAnimationKey, ViewmodelAnimations } from "shared/data/viewmodel-animations";
import { WeaponData, WeaponDataKey } from "shared/data/weapons";
import { PlayerCharacter } from "shared/types/player-character";

function addSpread(hit: Vector3, weapon: string) {
	const data = WeaponData[weapon];

	const randomVector = new Vector3(
		math.random(-data.spreadMin, data.spreadMax),
		0,
		math.random(-data.spreadMin, data.spreadMax),
	);

	return hit.add(randomVector);
}

function raycast(origin: Vector3, target: CFrame) {
	const direction = target.LookVector.mul(300);
	const result = Workspace.Raycast(origin, direction);

	const intersection = result !== undefined ? result.Position : origin.add(direction);

	return intersection;
}

function reload(weapon: { ammo: number; reserveAmmo: number; id: string }): {
	ammo: number;
	reserveAmmo: number;
	id: string;
} {
	const newWeapon = weapon;

	const data = WeaponData[weapon.id] as WeaponDataKey;

	// If the clip still has bullets left.
	if (newWeapon.ammo > 0) {
		if (newWeapon.reserveAmmo - (data.clipSize - newWeapon.ammo) <= 0) {
			newWeapon.ammo += newWeapon.reserveAmmo;
			newWeapon.reserveAmmo = 0;
		} else {
			newWeapon.reserveAmmo -= data.clipSize - newWeapon.ammo;
			newWeapon.ammo = data.clipSize;
		}
	} else {
		if (newWeapon.reserveAmmo - data.clipSize <= 0) {
			newWeapon.ammo += newWeapon.reserveAmmo;
			newWeapon.reserveAmmo = 0;
		} else {
			newWeapon.reserveAmmo -= data.clipSize;
			newWeapon.ammo = data.clipSize;
		}
	}

	return newWeapon;
}

function convertNumberKeycodeToIndex(key: Enum.KeyCode) {
	return key.Value - 48;
}

function filterCurrentWeapon(weapon: string, state: ClientState) {
	return state.weapons.filter((value) => {
		return value.id === weapon;
	});
}

@Controller({})
export class WeaponController implements OnStart {
	private mouse: Mouse | undefined;
	private viewmodel: Model | undefined;
	private stats: WeaponDataKey | undefined;
	//!TODO Refactor class to use this ⬆ stats value

	private adsGui: ScreenGui | undefined;
	private adsTween: Tween | undefined;

	private lastWeaponIndex: string = "";

	private weaponCooldowns: Array<{
		id: string;
		cooldown: number;
	}> = [];

	cooldown(id: string) {
		task.spawn(() => {
			let cooldownIndex = 0;

			const cooldownValue = this.weaponCooldowns.filter((value, index) => {
				if (value.id === id) {
					cooldownIndex = index;
				}
				return value.id === id;
			})[0];

			task.wait(cooldownValue.cooldown);
			this.weaponCooldowns.remove(cooldownIndex);
		});
	}

	onStart() {
		this.viewmodel = Workspace.CurrentCamera!.WaitForChild("Viewmodel") as Model;

		this.mouse = Players.LocalPlayer.GetMouse();
		UserInputService.MouseIconEnabled = false;

		const components = Dependency<Components>();
		let viewmodelComponent = components.getComponent<Viewmodel>(Players.LocalPlayer);

		this.stats = WeaponData[viewmodelComponent!.attributes.viewmodelType!] as WeaponDataKey;

		this.mouse!.Button1Down.Connect(() => {
			const state = clientState.getState();
			if (filterCurrentWeapon(state.currentWeaponId, state)[0].ammo > 0) {
				if (
					this.weaponCooldowns
						.filter((value) => {
							return value.id === viewmodelComponent!.attributes.viewmodelType;
						})
						.size() === 0
				) {
					viewmodelComponent = components.getComponent<Viewmodel>(Players.LocalPlayer);

					const viewmodelType = viewmodelComponent!.attributes.viewmodelType;
					this.viewmodel = Workspace.CurrentCamera?.WaitForChild("Viewmodel") as Model;
					Events.weapon.fire(
						`${viewmodelType}`,
						this.viewmodel!.PrimaryPart!.CFrame.Position,
						addSpread(
							raycast(this.viewmodel!.PrimaryPart!.CFrame.Position, this.mouse!.Hit!),
							viewmodelComponent!.attributes.viewmodelType!,
						),
					);

					this.weaponCooldowns.push({
						cooldown: WeaponData[viewmodelType].fireRate,
						id: viewmodelType,
					});
					this.cooldown(viewmodelType);
				}
			}
		});

		Events.weapon.fireVisual.connect((player, bulletType, origin, hit) => {
			const handle = this.viewmodel!.WaitForChild("Handle") as BasePart;

			// Send a request to play the sound originating from the fire point.
			Events.environment.playSound.fire(
				`${bulletType}.fire`,
				(handle.WaitForChild("FirePoint") as Attachment).WorldPosition,
				10,
			);

			// Check if the player is the same
			if (player === Players.LocalPlayer) {
				viewmodelComponent = components.getComponent<Viewmodel>(Players.LocalPlayer);

				const animation = new Instance("Animation");
				animation.AnimationId = (
					ViewmodelAnimations[viewmodelComponent!.attributes.viewmodelType!] as ViewmodelAnimationKey
				).Fire;
				animation.Name = "Fire";

				const state = clientState.getState();

				const currentWeapon = state.weapons.find((value) => {
					return value.id === state.currentWeaponId;
				});

				clientState.setWeapon({
					ammo: currentWeapon!.ammo - 1,
					reserveAmmo: currentWeapon!.reserveAmmo,
					id: currentWeapon!.id,
				});

				viewmodelComponent?.startAnimation(animation, false);
			}

			const character = player.Character as unknown as PlayerCharacter;

			const handleExternal = player
				.Character!.FindFirstChild("external_viewmodel")
				?.WaitForChild("Handle") as BasePart;
			const rightArm = player.Character!.FindFirstChild("Right Arm") as BasePart;

			const track = (character.Humanoid.WaitForChild("Animator") as Animator).LoadAnimation(
				Make("Animation", {
					AnimationId: ExternalAnimations[bulletType + ".fire"] as string,
				}),
			);

			track.Play();
		});

		UserInputService.InputBegan.Connect((input) => {
			// Reload
			if (input.KeyCode === Enum.KeyCode.R) {
				const state = clientState.getState();
				const weapon = state.weapons.filter((value) => {
					return value.id === state.currentWeaponId;
				})[0];

				viewmodelComponent = components.getComponent<Viewmodel>(Players.LocalPlayer);

				if (weapon.reserveAmmo > 0) {
					viewmodelComponent?.startAnimation(
						Make("Animation", {
							AnimationId: ViewmodelAnimations[viewmodelComponent!.attributes.viewmodelType].Reload,
							Name: "Reload",
						}),
						true,
					);
					clientState.setWeapon(reload(weapon));
				}
			}

			if (input.KeyCode.Value >= 49 && input.KeyCode.Value <= 57) {
				// The keycode is a number from [1-9]
				const index = convertNumberKeycodeToIndex(input.KeyCode) - 1;

				const state = clientState.getState();

				if (state.weapons.size() < index) {
					return;
				} else {
					clientState.setCurrentWeapon(
						state.weapons[index].id !== undefined ? state.weapons[index].id : state.weapons[0].id,
					);
					Events.weapon.switchExternalViewmodelType.fire(state.weapons[index].id);
				}
			}
		});

		// ADS
		const ADS_KEYBIND = Enum.UserInputType.MouseButton3;

		let ADSing = false;

		UserInputService.InputBegan.Connect((input) => {
			if (input.UserInputType === ADS_KEYBIND) {
				if (ADSing) {
					this.adsGui?.Destroy();
					this.adsTween?.Cancel();
					this.adsTween?.Destroy();
					(this.viewmodel?.Parent as Camera).FieldOfView = 70;

					ADSing = false;
				} else {
					const weapon = WeaponData[viewmodelComponent!.attributes.viewmodelType];

					if (weapon.ads.enabled) {
						this.adsGui = Make("ScreenGui", {
							Parent: Players.LocalPlayer.WaitForChild("PlayerGui"),
							Enabled: true,
							IgnoreGuiInset: true,
						});

						const imageLabel = Make("ImageLabel", {
							BackgroundTransparency: 1,
							Image: weapon.ads.image,
							Size: new UDim2(1, 0, 1, 0),
							AnchorPoint: new Vector2(0.5, 0),
							Parent: this.adsGui,
							Position: new UDim2(0.5, 0, 0, 0),
						});

						Make("Frame", {
							BackgroundColor3: new Color3(0, 0, 0),
							Size: new UDim2(0.25, 0, 1, 0),
							BorderSizePixel: 0,
							Parent: this.adsGui,
						});

						Make("Frame", {
							BackgroundColor3: new Color3(0, 0, 0),
							Size: new UDim2(0.25, 0, 1, 0),
							Position: new UDim2(0.75, 0, 0, 0),
							BorderSizePixel: 0,
							Parent: this.adsGui,
						});

						Make("UIAspectRatioConstraint", {
							AspectRatio: 1,
							Parent: imageLabel,
						});

						this.adsTween = TweenService.Create(
							this.viewmodel?.Parent as Camera,
							new TweenInfo(0.5, Enum.EasingStyle.Sine),
							{
								FieldOfView: 30,
							},
						);

						this.adsTween.Play();

						ADSing = true;
					}
				}
			}
		});
	}
}
