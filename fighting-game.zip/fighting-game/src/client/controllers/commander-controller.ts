import { Controller, OnStart } from "@flamework/core";
import { CommanderClient, CommanderInterface, DefaultPalette } from "@rbxts/commander";
import { vectorType } from "shared/types/commander/vector";

@Controller({})
export class CommanderController implements OnStart {
	onStart() {
		CommanderClient.start(
			(registry) => {
				registry.registerType(vectorType);
				registry.sync();
			},
			{
				shortcutsEnabled: true,
				interface: CommanderInterface.create({
					activationKeys: [Enum.KeyCode.F2],
					anchorPoint: new Vector2(0.5, 0),
					position: new UDim2(0.5, 0, 0.2, 0),
					size: new UDim2(0.5, 0, 0.1, 0),
					backgroundTransparency: 0.2,
					palette: DefaultPalette.builder,
					showShortcutSuggestions: true,
				}),
			},
		).catch((err) => {
			warn(`[CLIENT] Controllers/CommanderController: Could not be started: ${err}`);
		});
		print("[CLIENT] Controllers/CommanderController: Started!");
	}
}
