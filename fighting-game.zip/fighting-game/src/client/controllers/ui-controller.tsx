import { Controller, OnStart } from "@flamework/core";
import Make from "@rbxts/make";
import React, { StrictMode } from "@rbxts/react";
import { createRoot } from "@rbxts/react-roblox";
import { Players } from "@rbxts/services";
import { App } from "client/ui/app";

@Controller({})
export class UiController implements OnStart {
	onStart() {
		const rootInstance = Make("ScreenGui", {
			Name: "React_Managed_UI",
			IgnoreGuiInset: true,
			Parent: Players.LocalPlayer.WaitForChild("PlayerGui"),
		});

		const root = createRoot(rootInstance);

		root.render(
			<StrictMode>
				<App />
			</StrictMode>,
		);

		print("[CLIENT] Controllers/UiController: Started!");
	}
}
