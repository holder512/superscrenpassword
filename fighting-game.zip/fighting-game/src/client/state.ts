import { createProducer } from "@rbxts/reflex";
import { WeaponData } from "shared/data/weapons";

export interface ClientState {
	ui: {
		debugStateMenuVisible: boolean;
	};
	weapons: Array<{
		ammo: number;
		reserveAmmo: number;
		id: string;
	}>;
	currentWeaponId: string;
}

export const initialState: ClientState = {
	ui: {
		debugStateMenuVisible: false,
	},
	weapons: [
		{
			ammo: WeaponData.pistol.clipSize,
			reserveAmmo: WeaponData.pistol.ammo,
			id: "pistol",
		},
		{
			ammo: WeaponData.uzi.clipSize,
			reserveAmmo: WeaponData.uzi.ammo,
			id: "uzi",
		},
	],
	currentWeaponId: "pistol",
};

export const clientState = createProducer(initialState, {
	setDebugStateMenuVisible: (state: ClientState, visible: boolean) => ({
		...state,
		ui: {
			debugStateMenuVisible: visible,
		},
	}),
	setWeapon: (
		state,
		weapon: {
			ammo: number;
			reserveAmmo: number;
			id: string;
		},
	) => {
		const newWeaponsArray: Array<{
			ammo: number;
			reserveAmmo: number;
			id: string;
		}> = [];

		const weapons = state.weapons;

		weapons.forEach((value, index) => {
			if (value.id === weapon.id) {
				newWeaponsArray.push({
					ammo: weapon.ammo,
					reserveAmmo: weapon.reserveAmmo,
					id: weapon.id,
				});
			} else {
				newWeaponsArray.push(value);
			}
		});

		return {
			...state,
			weapons: newWeaponsArray,
		};
	},
	decrementAmmo: (state) => {
		const weapons = state.weapons;

		const weaponIndex = weapons.findIndex((value) => {
			return value.id === state.currentWeaponId;
		});

		weapons[weaponIndex] = {
			...weapons[weaponIndex],
			ammo: weapons[weaponIndex].ammo - 1,
		};

		return {
			...state,
			weapons: weapons,
		};
	},
	setCurrentWeapon: (state, index: string) => ({
		...state,
		currentWeaponId: index,
	}),
});
