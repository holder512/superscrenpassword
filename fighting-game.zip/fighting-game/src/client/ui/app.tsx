import { clientState } from "client/state";
import { ReflexProvider } from "@rbxts/react-reflex";
import { DebugUI } from "./debug-state";
import React from "@rbxts/react";
import { Cursor } from "shared/ui/cursor";

export function App() {
	return (
		<ReflexProvider producer={clientState}>
			<DebugUI />
			<Cursor />
		</ReflexProvider>
	);
}
