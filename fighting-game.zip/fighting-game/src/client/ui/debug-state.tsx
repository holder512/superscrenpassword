import React, { useState } from "@rbxts/react";
import { HttpService } from "@rbxts/services";
import { ClientState, clientState } from "client/state";
import { SharedState, sharedState } from "shared/state";

function transformState(state: object) {
	let reply = "";
	// eslint-disable-next-line roblox-ts/no-array-pairs
	for (const [key, value] of pairs(state)) {
		if (type(value) === "table") {
			reply += `--- TABLE ---\n`;
			reply += `[${key}]:${HttpService.JSONEncode(value)}\n`;
		} else {
			reply += `[${key}]: ${value}\n`;
		}
	}

	return reply;
}

export function DebugUI() {
	const [clientStateObject, setClientStateObject] = useState(clientState.getState());
	const [sharedStateObject, setSharedStateObject] = useState(sharedState.getState());

	const selectClientState = (state: ClientState) => {
		return state;
	};

	const selectSharedState = (state: SharedState) => {
		return state;
	};

	const selectVisible = (state: ClientState) => {
		return state.ui.debugStateMenuVisible;
	};

	const [visible, setVisible] = useState(false);

	clientState.subscribe(selectClientState, (state) => {
		setClientStateObject(state);
	});

	sharedState.subscribe(selectSharedState, (state) => {
		setSharedStateObject(state);
	});

	clientState.subscribe(selectVisible, (state) => {
		setVisible(state);
	});

	return (
		<>
			<textlabel
				Draggable
				TextWrapped
				Text={transformState(clientStateObject)}
				Size={new UDim2(0, 500, 0.2, 0)}
				AnchorPoint={new Vector2(0.5, 0)}
				Position={new UDim2(0.5, 0, 0, 0)}
				BackgroundTransparency={1}
				TextColor3={new Color3(0, 1, 0)}
				TextStrokeColor3={new Color3(0, 0, 0)}
				TextStrokeTransparency={0}
				Visible={visible}
			></textlabel>
			<textlabel
				Draggable
				TextWrapped
				Text={transformState(sharedStateObject)}
				Size={new UDim2(0, 500, 0.2, 0)}
				AnchorPoint={new Vector2(0.5, 0)}
				Position={new UDim2(0.5, 0, 0, 500)}
				BackgroundTransparency={1}
				TextColor3={new Color3(1, 1, 0)}
				TextStrokeColor3={new Color3(0, 0, 0)}
				TextStrokeTransparency={0}
				Visible={visible}
			></textlabel>
		</>
	);
}
