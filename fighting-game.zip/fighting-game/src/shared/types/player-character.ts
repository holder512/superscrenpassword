export type PlayerCharacter = {
	Head: BasePart;
	HumanoidRootPart: BasePart;
	Humanoid: Humanoid;
	"Left Arm": BasePart;
	"Right Arm": BasePart;
	"Left Leg": BasePart;
	"Right Leg": BasePart;
	Torso: BasePart;
};
