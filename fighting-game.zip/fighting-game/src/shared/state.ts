import { createProducer } from "@rbxts/reflex";

export interface SharedState {}

export const initialState: SharedState = {};

export const sharedState = createProducer(initialState, {});
