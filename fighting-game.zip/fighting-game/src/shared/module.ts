export function makeHello(name: string) {
	return `Hello from ${name}!`;
}
