import React from "@rbxts/react";

export function Cursor() {
	return (
		<frame
			BackgroundColor3={new Color3(0, 1, 0)}
			Size={new UDim2(0, 4, 0, 4)}
			AnchorPoint={new Vector2(0.5, 0.5)}
			Position={new UDim2(0.5, 0, 0.5, 0)}
			BorderSizePixel={0}
		>
			{/* <uicorner CornerRadius={new UDim(1, 0)} /> */}
		</frame>
	);
}
