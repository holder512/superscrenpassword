import { Networking } from "@flamework/networking";

interface ClientToServerEvents {
	weapon: {
		fire(bulletType: string, origin: Vector3, hit: Vector3): void;
		switchExternalViewmodelType(newViewmodelType: string): void;
	};
	environment: {
		playSound(id: string, origin?: Vector3, loudness?: number): void;
	};
}

interface ServerToClientEvents {
	debug: {
		showStateUI: () => void;
	};
	weapon: {
		fireVisual: (player: Player, bulletType: string, origin: Vector3, hit: Vector3) => void;
	};
	environment: {
		broadcastSound(id: string, origin?: Vector3, loudness?: number): void;
		switchExternalViewmodelType(newViewmodelType: string): void;
	};
	character: {
		initialize: () => void;
	};
	toggleFreeCameraMode: () => void;
}

interface ClientToServerFunctions {}

interface ServerToClientFunctions {}

export const GlobalEvents = Networking.createEvent<ClientToServerEvents, ServerToClientEvents>();
export const GlobalFunctions = Networking.createFunction<ClientToServerFunctions, ServerToClientFunctions>();
