import { CommandContext } from "@rbxts/commander";
import { RunService } from "@rbxts/services";
import { GROUP_ID } from "shared/constants";

export function isAdmin(context: CommandContext) {
	return context.executor!.GetRankInGroup(GROUP_ID) !== -1;
}
