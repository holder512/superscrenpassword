import { CommandContext } from "@rbxts/commander";
import { RunService } from "@rbxts/services";

export function isStudio(context: CommandContext) {
	return RunService.IsStudio();
}
