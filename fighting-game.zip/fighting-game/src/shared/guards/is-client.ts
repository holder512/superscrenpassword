import { CommandContext } from "@rbxts/commander";
import { RunService } from "@rbxts/services";

export function isClient(context: CommandContext) {
	return RunService.IsClient();
}
