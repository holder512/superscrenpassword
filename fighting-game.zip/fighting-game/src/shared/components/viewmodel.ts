import { Dependency, OnRender, OnStart } from "@flamework/core";
import { Component, BaseComponent, Components } from "@flamework/components";
import { ReplicatedStorage, Workspace } from "@rbxts/services";
import { ViewmodelAnimationKey, ViewmodelAnimations } from "shared/data/viewmodel-animations";

interface Attributes {
	viewmodelType: string;
}

const AnimationPriority: { [key: string]: { looped: boolean; priority: Enum.AnimationPriority } } = {
	Equip: {
		looped: false,
		priority: Enum.AnimationPriority.Action,
	},
	Idle: {
		looped: true,
		priority: Enum.AnimationPriority.Idle,
	},
	Fire: {
		looped: false,
		priority: Enum.AnimationPriority.Action3,
	},
	Reload: {
		looped: false,
		priority: Enum.AnimationPriority.Action,
	},
	Shove: {
		looped: true,
		priority: Enum.AnimationPriority.Action4,
	},
};

@Component({
	tag: "game.viewmodel",
	defaults: {
		viewmodelType: "pistol",
	},
})
export class Viewmodel extends BaseComponent<Attributes> implements OnStart, OnRender {
	private loadingComplete: boolean = false;
	private viewmodel: Model | undefined = undefined;
	private connection: RBXScriptConnection | undefined = undefined;

	start() {
		if (this.viewmodel) this.refreshViewmodel();

		this.viewmodel = ReplicatedStorage.WaitForChild("assets")
			.WaitForChild("viewmodels")
			.WaitForChild(this.attributes.viewmodelType)
			.Clone() as Model;

		this.viewmodel!.Parent = Workspace.CurrentCamera;
		this.viewmodel!.Name = "Viewmodel";

		this.viewmodel!.GetDescendants()
			.filter((value) => value.IsA("BasePart"))
			.forEach((value) => {
				(value as BasePart).CanCollide = false;
				(value as BasePart).CanTouch = false;
				(value as BasePart).CanQuery = false;
				(value as BasePart).Anchored = false;
				(value as BasePart).Massless = true;
				(value as BasePart).CastShadow = false;
			});
		this.loadingComplete = true;

		const equipAnimation = new Instance("Animation");
		equipAnimation.AnimationId = (
			ViewmodelAnimations[this.attributes.viewmodelType] as ViewmodelAnimationKey
		).Equip;
		equipAnimation.Name = "Equip";
		const idleAnimation = new Instance("Animation");
		idleAnimation.AnimationId = (ViewmodelAnimations[this.attributes.viewmodelType] as ViewmodelAnimationKey).Idle;
		idleAnimation.Name = "Idle";

		// this.startAnimation(equipAnimation, false);
		this.startAnimation(idleAnimation, false);
	}

	onStart() {
		this.start();
	}

	onRender(deltaTime: number): void {
		if (!this.loadingComplete) return;
		this.viewmodel!.PivotTo(Workspace.CurrentCamera!.GetRenderCFrame());
	}

	refreshViewmodel() {
		Workspace.CurrentCamera!.WaitForChild("Viewmodel").Destroy();
		this.viewmodel = undefined;
		if (this.connection) {
			this.connection.Disconnect();
		}
	}

	switchWeapon(id: string) {
		this.attributes.viewmodelType = id;
	}

	startAnimation(animation: Animation, waitForAnimation: boolean) {
		this.viewmodel = Workspace.CurrentCamera?.WaitForChild("Viewmodel") as Model;
		if (
			// eslint-disable-next-line roblox-ts/lua-truthiness
			(this.viewmodel?.WaitForChild("AnimationController").WaitForChild("Animator") as Animator)
				.GetPlayingAnimationTracks()
				.filter((value) => {
					return value.Name === animation.Name;
				})[0]
		) {
			(this.viewmodel?.WaitForChild("AnimationController").WaitForChild("Animator") as Animator)
				.GetPlayingAnimationTracks()
				.filter((value) => {
					return value.Name === animation.Name;
				})[0]
				.Play();
		} else {
			const Animation = (
				this.viewmodel?.WaitForChild("AnimationController").WaitForChild("Animator") as Animator
			).LoadAnimation(animation);

			Animation.Looped = AnimationPriority[animation.Name].looped;
			Animation.Priority = AnimationPriority[animation.Name].priority;
			Animation.Play();

			if (waitForAnimation) {
				Animation.Stopped.Wait();
			}
		}
	}

	endAnimation(animation: Animation) {
		if (
			(this.viewmodel?.WaitForChild("AnimationController").WaitForChild("Animator") as Animator)
				.GetPlayingAnimationTracks()
				.filter((value) => {
					return value.Name === animation.Name;
				})[0]
		) {
			(
				(this.viewmodel?.WaitForChild("AnimationController").WaitForChild("Animator") as Animator)
					.GetPlayingAnimationTracks()
					.filter((value) => {
						return value.Name === animation.Name;
					})[0] as AnimationTrack
			).Stop();
		}
	}
}
