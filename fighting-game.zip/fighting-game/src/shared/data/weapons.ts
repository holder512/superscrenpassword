export enum WeaponFireType {
	FULL_AUTO,
	SEMI_AUTO,
}

export type WeaponDataKey = {
	spreadMax: number; // The maximum spread value on a weapon. Use 0 to disable.
	spreadMin: number; // The minimum spread value on a weapon. Use 0 to disable.
	showCrosshair?: boolean; // Does the crosshair show when play is holding the weapon?
	fireRate: number; // How many bullets can be fired per second, e.g 2 -> 0.5 cooldown
	fireType: WeaponFireType; // The fire method of the weapon.
	ammo: number; // The amount of ammo the weapon has.
	clipSize: number; // The amount of bullets in the clip.
	reloadTime: number; // How long the animation takes.
	ads: {
		enabled: boolean;
		image?: string;
	};
	damage: number;
};

export const WeaponData: { [key: string]: WeaponDataKey } = {
	pistol: {
		spreadMax: 1,
		spreadMin: 1,
		showCrosshair: true,
		fireRate: 0.5,
		fireType: WeaponFireType.SEMI_AUTO,
		ammo: 70,
		clipSize: 14,
		reloadTime: 2,
		ads: {
			enabled: false,
			image: "rbxassetid://420303795",
		},
		damage: 20,
	},
	uzi: {
		spreadMax: 4,
		spreadMin: 1,
		showCrosshair: true,
		fireRate: 0.1,
		fireType: WeaponFireType.SEMI_AUTO,
		ammo: 128,
		clipSize: 32,
		reloadTime: 4,
		ads: {
			enabled: false,
		},
		damage: 7,
	},
};
