export const ExternalAnimations: { [K: string]: string } = {
	"pistol.fire": "rbxassetid://17856064299",
	"pistol.idle": "rbxassetid://17856057999",
};
