export interface SoundType {
	name: string;
	id: string;
}

export const sounds: Array<SoundType> = [
	{
		name: "pistol.fire",
		id: "rbxassetid://17713289902",
	},
	{
		name: "pistol.reload",
		id: "rbxassetid://17713294117",
	},
	{
		name: "env.glass-shatter",
		id: "rbxassetid://16976886499",
	},
	{
		name: "uzi.fire",
		id: "rbxassetid://17755330824",
	},
	{
		name: "uzi.reload",
		id: "rbxassetid://17713294117",
	},
];
