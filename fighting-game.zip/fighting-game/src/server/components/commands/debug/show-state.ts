import { Controller, OnStart } from "@flamework/core";
import { Commander, Command, CommandContext, Guard } from "@rbxts/commander";
import { Events } from "server/network";
import { isStudio } from "shared/guards/is-studio";

@Commander
export class PrintStateCommand {
	@Command({
		name: "debug.showstate",
		description: "Toggles the shared and client state debug interface.",
		shortcuts: [Enum.KeyCode.KeypadOne],
	})
	run(context: CommandContext) {
		Events.debug.showStateUI.fire(context.executor!);
		context.reply(`Toggled debug state interface.`);
	}
}
