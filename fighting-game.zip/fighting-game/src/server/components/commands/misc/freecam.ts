import { Controller, OnStart } from "@flamework/core";
import { Commander, Command, CommandContext, Guard } from "@rbxts/commander";
import { Events } from "server/network";
import { isAdmin } from "shared/guards/is-admin";

@Commander
export class Freecam {
	@Command({
		name: "freecam",
		shortcuts: [Enum.KeyCode.KeypadZero],
	})
	@Guard(isAdmin)
	run(context: CommandContext) {
		Events.toggleFreeCameraMode.fire(context.executor!);
		context.reply(`Toggled free camera mode.`);
	}
}
