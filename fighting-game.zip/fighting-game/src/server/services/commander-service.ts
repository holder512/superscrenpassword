import { Service, OnStart } from "@flamework/core";
import { CommanderServer, CommanderType } from "@rbxts/commander";
import { vectorType } from "shared/types/commander/vector";

@Service({})
export class CommanderService implements OnStart {
	onStart() {
		print("Services/CommanderService: Started!");
		CommanderServer.start((registry) => {
			registry.registerType(vectorType);
		}).catch((err) => {
			warn(`Services/CommanderService: Could not be started: ${err}`);
		});
	}
}
