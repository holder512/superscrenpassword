import { Service, OnStart } from "@flamework/core";
import { Players, ReplicatedStorage, Workspace } from "@rbxts/services";
import { Events } from "server/network";
import { WeaponData } from "shared/data/weapons";
import { PlayerCharacter } from "shared/types/player-character";

@Service({})
export class WeaponService implements OnStart {
	onStart() {
		Events.weapon.fire.connect((player, bulletType, origin, hit) => {
			const raycastResult = Workspace.Raycast(origin, hit.sub(origin).Unit.mul(300));

			if (raycastResult) {
				const hitInstance = raycastResult.Instance;
				print(hitInstance.Name);

				const hitHumanoid = hitInstance.Parent?.FindFirstChildOfClass("Humanoid") as Humanoid;
				if (hitHumanoid) {
					hitHumanoid.Health -= WeaponData[bulletType]!.damage;
				}
			}
			Events.weapon.fireVisual.broadcast(player, bulletType, origin, hit);
		});

		Events.weapon.switchExternalViewmodelType.connect((player, newViewmodelType) => {
			while (!player.Character) task.wait();

			const externalViewmodelWeapon = ReplicatedStorage.WaitForChild("assets")
				.WaitForChild("external_animation_models")
				.WaitForChild(newViewmodelType)
				.Clone() as Model;

			const currentExternalViewmodel = player.Character.FindFirstChild("external_viewmodel");
			if (currentExternalViewmodel) {
				currentExternalViewmodel.Destroy();
			}

			const rightArm = player.Character.WaitForChild("Right Arm", 10) as BasePart;
			const rightGripAttachment = rightArm?.FindFirstChild("RightGripAttachment") as Attachment;

			if (rightGripAttachment) {
				externalViewmodelWeapon.Name = "external_viewmodel";
				externalViewmodelWeapon.Parent = player.Character;

				// Create Motor6D to attach the handle to the right arm
				const motor6D = new Instance("Motor6D");
				motor6D.Part0 = rightArm;
				motor6D.Part1 = externalViewmodelWeapon.PrimaryPart!;
				motor6D.Parent = rightArm;

				// Adjust the C0 and C1 values to position the gun correctly
				const handle = externalViewmodelWeapon.PrimaryPart as BasePart;
				motor6D.C0 = new CFrame(0, 0, 0);

				const orientationInDegrees = new Vector3(-90, 90, 0);

				// Convert the orientation from degrees to radians
				const orientationInRadians = new Vector3(
					math.rad(orientationInDegrees.X),
					math.rad(orientationInDegrees.Y),
					math.rad(orientationInDegrees.Z),
				);

				// Create the CFrame with the desired orientation
				const cframeWithOrientation = CFrame.Angles(
					orientationInRadians.Y,
					orientationInRadians.Z,
					orientationInRadians.X,
				);

				motor6D.C1 = new CFrame(1, -0.5, 0).mul(cframeWithOrientation);

				// Update the Handle's CFrame to match the RightGripAttachment
				externalViewmodelWeapon.SetPrimaryPartCFrame(rightGripAttachment.WorldCFrame);
			}
		});

		print("Service/WeaponService: Started!");
	}
}
