import { Service, OnStart } from "@flamework/core";
import { PhysicsService, Players } from "@rbxts/services";

@Service({})
export class CollisionGroupService implements OnStart {
	onStart() {
		PhysicsService.RegisterCollisionGroup("player");

		PhysicsService.CollisionGroupSetCollidable("player", "player", false);
		PhysicsService.CollisionGroupSetCollidable("player", "Default", true);

		Players.PlayerAdded.Connect((player) => {
			while (player.Character === undefined) task.wait();

			player.Character.GetDescendants().forEach((instance) => {
				if (instance.IsA("BasePart")) {
					instance.CollisionGroup = "player";
				}
			});
		});
		print("Services/CollisionGroupService: Started!");
	}
}
